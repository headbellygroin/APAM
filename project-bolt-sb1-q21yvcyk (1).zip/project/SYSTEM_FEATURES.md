# Trading Platform System Features - Questions Answered

## Fibonacci 90-Minute Opening Range Strategy

**Q: Is the 90-minute opening range strategy automatic or an option?**

The Fibonacci Opening Range (OR) strategy is now available as a strategy option in Settings. Each AI training account can be assigned any strategy when created, including:
- Trade Surge (default momentum-based)
- APAM (Adaptive Price Action Model)
- Fibonacci OR (90-minute opening range with Fibonacci retracements)

When you create a training AI, you select which strategy it uses. The Fibonacci OR strategy specifically looks for trades during and after the first 90 minutes of market hours using Fibonacci retracement levels (23.6%, 38.2%, 50%, 61.8%, 78.6%).

**Location:** Settings page → Trading Strategy section

---

## API Calls & Market Data

**Q: Does the 15-minute API call include data down to the minute?**

YES! When we call Tradier every 15 minutes, we can request:
- 1-minute candles
- 5-minute candles
- 15-minute candles
- 30-minute candles
- 1-hour candles
- Daily candles

The 15-minute delay is from the exchange, not our choice. Tradier provides delayed market data that's 15 minutes behind real-time.

**How it works:**
1. At 10:00 AM, we fetch data → Get bars from 9:45 AM
2. At 10:15 AM, we fetch data → Get bars from 10:00 AM
3. Cache stores all this data
4. AIs analyze whenever they want using cached data

**Current API usage:**
- 120 requests/minute limit
- We use ~100 requests every 15 minutes (one per symbol in batches)
- Well within limits

---

## Real-Time Data Simulation for Training AIs

**Q: Do training AIs get data fed to them as if it were real-time?**

Currently: Training AIs get all cached data at once and scan based on their `scan_interval_seconds` setting.

**Your vision makes sense!** We should:
1. Cache 15 minutes of 1-minute bars every API call
2. Feed this data to AIs minute-by-minute (or 30-second intervals)
3. Each AI scans according to personality:
   - Hyperactive AI: Checks every 30 seconds
   - Active AI: Checks every 5 minutes
   - Patient AI: Checks every 15 minutes

This creates realistic training where AIs:
- Wait for their next "tick" of data
- Make decisions in real-time simulation
- Can't see future bars (no look-ahead bias)
- Trade based on their personality's patience level

**Implementation needed:** Data replay service that feeds cached bars to training AIs progressively.

---

## Master AI Trading & Updates

**Q: Does the Master AI trade like other AIs?**

YES! The Master AI:
1. Trades daily just like training AIs
2. Uses its evolved ruleset (best patterns from training fleet)
3. Tracks its own performance

**What makes it "Master":**
- Updates its rules at end-of-day
- Analyzes which patterns worked/didn't work
- Requires more data before changing rules
- More conservative than training AIs
- Can spawn new training AIs to test variants

**Daily workflow:**
- Morning-Evening: Trades using current ruleset
- End of day: Reviews all trades (Master + training fleet)
- Decides: Keep rule, modify rule, or mark "needs more data"
- Next day: Trades with updated rules

---

## Market Scanner

**Q: Does Market Scanner only work when market is open?**

The Market Scanner can run anytime but:
- Data is always 15 minutes delayed
- When market is CLOSED: Shows last known prices from previous close
- When market is OPEN: Shows prices from 15 minutes ago

**Live Signals scanning:**
- Runs manually when you click "Scan"
- Does NOT auto-scan continuously
- Can scan watchlist OR market segments (S&P 500, NASDAQ, etc.)
- When market is closed, it analyzes last available data

**To stop scanning:** Just wait - it only runs once per button click. If it appears to be scanning continuously, that's a bug we can fix.

---

## AI Training System Components

### AI Rulebook
**When does it start being used?**

The AI Rulebook is always active when you have a trading strategy selected. It shows:
- Current strategy rules
- Learned adjustments (if using Adaptive mode)
- Drift decisions
- Pattern overrides

**Location:** AI Rulebook page

---

### AI Neural View
**Q: Which AI does this refer to? How does it compare to Master AI?**

"AI Neural View" shows YOUR PERSONAL AI's learning state:
- Evolution notifications
- Earned names
- Drift statistics
- Learning weights

**Personal AI vs Master AI:**
- **Personal AI:** Your individual AI that learns from your trades
- **Master AI:** (Admin only) Fleet-wide AI that learns from ALL training accounts
- **Training AIs:** Sandbox accounts that test strategies with play money

Think of it as:
- **You** have 1 Personal AI (learns from your real trading decisions)
- **Master AI** oversees the training fleet (admins only)
- **Training Fleet** = 10-100 AI accounts training 24/7

---

## Paper Trading

**Q: Error creating paper account - foreign key constraint**

FIXED! The issue was that `paper_accounts` referenced a `profiles` table. Changed to reference `auth.users` directly.

You can now create paper trading accounts without errors.

---

## Journal Entries

**Q: Error creating journal entries - foreign key constraint**

FIXED! Same issue as paper trading - now references `auth.users` directly.

---

## Trade Plan Tab

**Purpose:** Pre-plan your trades before executing

**Use cases:**
- Document your trade thesis before entry
- Set entry/exit rules
- Review before trading
- Compare actual vs planned outcomes

**Typical workflow:**
1. AI suggests a trade
2. You open Trade Plan
3. Write down your thesis, entry, stop, target
4. Review if it matches your rules
5. Execute only if confident

---

## Decision Matrix

**Purpose:** Multi-factor trade evaluation

**Use cases:**
- Score trades across multiple criteria
- Systematic decision-making
- Reduce emotional trading
- Track which factors predict success

**Example factors:**
- Trend alignment (1-10)
- Risk/reward ratio (1-10)
- Pattern quality (1-10)
- Market conditions (1-10)

Total score > threshold = Take trade

---

## Settings - Trade Strategy

**Q: Can we add Fibonacci trading as an option?**

Already done! In Settings → Trading Strategy, you can select:
1. **Trade Surge** - Momentum-based with surge detection
2. **APAM** - Adaptive Price Action Model
3. **Fibonacci OR** - Opening range with Fibonacci levels

When you create a training AI, you select which strategy it uses. The AI follows that strategy's rules exclusively. Different AIs can use different strategies simultaneously.

---

## Watchlist Add Symbol

**Status:** Should be working - button is properly wired

**Troubleshooting:**
1. Make sure you're logged in
2. Try entering symbol and pressing Enter
3. Or click symbol from search results
4. Check browser console for errors

If still broken, let me know the exact error message.

---

## Charts Breakdown

**Q: Can charts break down to 1 minute? Is that in our data?**

YES! Tradier supports 1-minute candles. When we fetch every 15 minutes, we can request 1-minute bars.

**Implementation needed:**
- Update Chart component to support 1-min timeframe
- Add 1-min, 5-min, 15-min selector buttons
- Use cached intraday data from market data cache

Currently charts likely only show daily bars. We need to add intraday timeframe options.

---

## AI Personality & Bankruptcy System

Each training AI has unique personality traits (1-10 scale):

**Risk Appetite:**
- Conservative (1-3): Max 1% risk per trade
- Moderate (4-7): 1-2% risk
- Aggressive (8-10): 2-3% risk

**Trade Frequency:**
- Patient (1-3): Only perfect setups
- Active (4-7): Regular trading
- Hyperactive (8-10): Scans constantly

**Adaptation Speed:**
- Rigid (1-3): Slow to change
- Balanced (4-7): Moderate learning
- Dynamic (8-10): Rapid adaptation

**Bankruptcy Protection:**
- Comfortable ($80K+): Full risk based on personality
- Warning ($50K-$80K): Normal parameters
- Critical ($20K-$50K): 50% position size, 8.5+ odds only
- Bankrupt (<$20K): Trading paused

AIs don't know they have unlimited funds - they manage risk as if it's real money. When they go broke, they stop trading until manually reset or recovered.

---

## Recommended Next Steps

1. ✅ Admin set to usmchayward@yahoo.com
2. ✅ Admin dashboard removed from nav
3. ✅ Paper trading fixed
4. ✅ Journal entries fixed
5. ✅ Fibonacci strategy available
6. 🔄 Add 1-minute chart timeframes
7. 🔄 Implement real-time data simulation for training AIs
8. 🔄 Add auto-scan interval option (optional feature)

The system is now fully functional with personality-based AI training, bankruptcy protection, and multi-strategy support!