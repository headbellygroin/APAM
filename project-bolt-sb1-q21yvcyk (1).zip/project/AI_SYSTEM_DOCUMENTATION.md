# AI Trading Platform - System Documentation

## Overview
This is an advanced AI-powered paper trading platform that uses evolutionary algorithms and multi-generational AI systems to discover, test, and optimize trading strategies. The system is built with React/TypeScript frontend, Supabase backend, and integrates with Tradier for market data.

---

## API Configuration

### Tradier API (Market Data Only)
- **Account ID**: `VA26427410`
- **API Key**: `IlAOBCioMansvg4BWXEd8kCOuoAF`
- **Base URL**: `https://api.tradier.com/v1`
- **Data Delay**: 15 minutes (live market feed, not real-time)
- **Usage**: Market data ONLY - all trading is simulated internally
- **Trading Operations**: BLOCKED at multiple layers (edge function, API client, trading service)

### Supabase Configuration
- Connection details stored in `.env` file
- Database tables handle all data persistence
- Edge functions proxy Tradier API calls
- Row Level Security (RLS) enabled on all tables

### Edge Function Secrets (Must be configured in Supabase Dashboard)
```
TRADIER_API_KEY=IlAOBCioMansvg4BWXEd8kCOuoAF
TRADIER_ACCOUNT_ID=VA26427410
```

---

## Core Architecture

### 1. Data Flow
```
Tradier API (15-min delayed)
  → Edge Function (tradier-proxy)
  → Frontend (tradierApi.ts)
  → AI Engines
  → Paper Trading Simulator
  → Supabase Database
```

### 2. Key Components

#### Market Data Layer (`src/lib/tradierApi.ts`)
- Fetches quotes, historical data, intraday data
- Symbol search functionality
- Market clock and calendar
- **Trading operations are BLOCKED** - throws errors on placeOrder/cancelOrder attempts

#### Trading Layer (`src/lib/tradierTrading.ts`)
- All trading methods return errors/blocked messages
- Only paper trading execution is allowed via `executeAIRecommendation()`
- Integrates with Supabase `paper_accounts` and `simulated_trades` tables

#### Paper Trading Simulator (`src/lib/tradeSimulator.ts`)
- Simulates trade execution with realistic fills
- Tracks P&L, position sizing, and risk management
- Integrates trading fees and slippage

---

## AI System Architecture

### Multi-Tier AI Structure

The platform implements a **generational AI evolution system** with three tiers:

1. **Training AI Accounts** (Generation 0)
   - Multiple AI instances run simultaneously on paper trading accounts
   - Each uses different strategy configurations and risk parameters
   - Compete against each other to find profitable patterns
   - Track record stored in `ai_training_accounts` table

2. **Master AI** (Generation 1)
   - Spawned from successful training accounts (performance threshold)
   - Manages its own paper trading account with real capital
   - Can spawn child training accounts to test new ideas
   - Tracks lineage and evolution path

3. **Evolved Rulesets** (Meta-layer)
   - Successful patterns discovered by training AIs are codified
   - Stored in `ai_evolved_rulesets` table
   - Can be promoted to production strategies
   - Version controlled with performance metrics

---

## AI Engine Details

### 1. Main AI Engine (`src/lib/aiEngine.ts`)

**Purpose**: Generate trade recommendations based on market data and technical analysis

**Key Functions**:
- `generateRecommendation(symbol, chartData, accountBalance)`: Analyzes market conditions and returns trade signal
- Confidence scoring (0-100)
- Odds scoring for risk/reward analysis
- Entry, stop-loss, and target price calculations

**Decision Logic**:
- Trend analysis (moving averages, momentum)
- Volume confirmation
- Support/resistance levels
- Risk/reward ratio validation (minimum 2:1)

**Output**: `AIRecommendation` object with:
```typescript
{
  symbol: string
  action: 'long' | 'short'
  confidenceScore: number
  oddsScore: number
  entryPrice: number
  stopLoss: number
  targetPrice: number
  reasoning: string
}
```

### 2. AI Evolution System (`src/lib/aiEvolution.ts`)

**Purpose**: Track AI performance and manage evolution/spawning

**Key Functions**:
- `trackEvolutionState()`: Records AI decisions and parameter changes
- `promoteToMaster()`: Elevates high-performing training AI
- `spawnChildAccount()`: Creates new training AI with mutated parameters
- `rollbackDrift()`: Reverts unsuccessful parameter changes

**Evolution Mechanics**:
- Performance thresholds determine promotion eligibility
- Parameter mutation for exploration (learning rate, risk tolerance, etc.)
- Lineage tracking via `account_lineage` table
- A/B testing through parallel training accounts

**Database Tables**:
- `ai_evolution_state`: Current AI configuration and parameters
- `ai_learned_adjustments`: Historical parameter changes
- `ai_drift_rollbacks`: Failed experiments that were reverted

### 3. AI Drift Detection (`src/lib/aiDriftEngine.ts`)

**Purpose**: Monitor AI performance degradation and trigger corrections

**Key Functions**:
- `detectDrift()`: Analyzes recent performance vs baseline
- `shouldRollback()`: Determines if recent changes hurt performance
- `calculateDriftScore()`: Quantifies performance deviation

**Drift Indicators**:
- Win rate decline > 15%
- Average loss > average win
- Consecutive losses > threshold
- Sharpe ratio deterioration

**Actions on Drift Detection**:
1. Log drift event to `ai_drift_rollbacks`
2. Revert to last known good configuration
3. Optionally spawn new training account to test alternative approach

### 4. Master AI Orchestrator (`src/lib/masterAIOrchestrator.ts`)

**Purpose**: Coordinate multiple AI instances and manage meta-strategy

**Key Functions**:
- `evaluateTrainingAccounts()`: Compare performance across all training AIs
- `decideSpawn()`: Determine when/what to spawn based on portfolio needs
- `allocateCapital()`: Distribute capital among AI instances
- `consolidateSignals()`: Aggregate signals from multiple AIs

**Meta-Strategy**:
- Portfolio diversification across AI approaches
- Ensemble learning (combine multiple AI signals)
- Resource allocation based on recent performance
- Automatic scaling (more capital to winners, less to losers)

**Spawn Decision Logic**:
```
IF training_ai.win_rate > 60% AND profit > 10%
  → Promote to Master AI

IF master_ai discovers new pattern
  → Spawn training AI to validate pattern

IF portfolio lacks exposure to sector/timeframe
  → Spawn specialized training AI
```

### 5. Pattern Discovery (`src/lib/patternDiscovery.ts`)

**Purpose**: Automatically identify recurring profitable patterns

**Key Functions**:
- `discoverPatterns()`: Analyzes historical trades for commonalities
- `validatePattern()`: Backtests discovered pattern
- `codifyPattern()`: Converts pattern to executable ruleset

**Pattern Types**:
- Price action patterns (breakouts, reversals, consolidations)
- Time-based patterns (day of week, time of day)
- Volume patterns (surge, drying up)
- Correlation patterns (sector rotation, pairs)

**Discovery Process**:
1. Scan profitable trades for common features
2. Statistical validation (minimum sample size, significance)
3. Forward testing on new data
4. If validated → save to `ai_discovered_patterns`
5. If consistently profitable → promote to `ai_evolved_rulesets`

### 6. Signal Tracking (`src/lib/signalTrackRecord.ts`)

**Purpose**: Maintain track record for all AI-generated signals

**Key Functions**:
- `recordSignal()`: Log new signal to database
- `updateOutcome()`: Mark signal as winner/loser after trade completes
- `calculateAccuracy()`: Win rate by signal type/AI instance
- `getSignalHistory()`: Retrieve historical performance

**Metrics Tracked**:
- Signal accuracy by symbol, timeframe, strategy
- Average risk/reward achieved vs predicted
- Time to target/stop hit
- Market condition context (trending, ranging, volatile)

---

## AI Training Account System

### Training Account Lifecycle

**Phase 1: Spawning**
- New training account created with initial capital (typically $10,000 virtual)
- Assigned strategy parameters (randomly mutated or inherited from parent)
- Linked to parent account via `account_lineage` table
- Logged in `master_ai_spawn_log` with action='spawn'

**Phase 2: Training**
- Executes trades based on assigned strategy
- All trades recorded in `simulated_trades` table
- Performance metrics updated continuously
- Evolution state tracked in `ai_evolution_state`

**Phase 3: Evaluation**
- After minimum sample size (e.g., 20 trades or 30 days)
- Metrics analyzed: win rate, profit factor, max drawdown, Sharpe ratio
- Compared against peer training accounts
- Decision: promote, continue, or terminate

**Phase 4: Promotion or Termination**
- **Promote**: If performance exceeds threshold → becomes Master AI
  - Gets real capital allocation from main account
  - Can spawn its own child training accounts
  - Logged as action='promote' in spawn log
- **Terminate**: If underperforming → account closed
  - Capital returned to pool
  - Strategy parameters logged as unsuccessful
  - Logged as action='terminate'

### Master AI Capabilities

**Spawning Children**:
- Master AI can create 2-5 child training accounts
- Children test variations of parent strategy
- Exploration vs exploitation balance

**Capital Management**:
- Starts with allocated capital (e.g., $50,000 virtual)
- Can request more capital based on performance
- Can distribute capital to child accounts

**Strategy Evolution**:
- Learns from child account performance
- Integrates successful child strategies
- Abandons unsuccessful approaches

---

## Real-World Event Integration

### Event Tracking System (`src/lib/realWorldEvents.ts`)

**Purpose**: Correlate market moves with real-world events

**Key Functions**:
- `recordEvent()`: Log event with metadata (type, severity, affected sectors)
- `correlateWithTrades()`: Link events to anomalous market behavior
- `predictImpact()`: Use historical event data to forecast market reaction

**Event Types**:
- Earnings reports
- Economic data releases (jobs, CPI, GDP)
- Fed announcements
- Geopolitical events
- Sector-specific news

**AI Learning from Events**:
1. Detect anomalous price movement
2. Search for contemporaneous events
3. Record correlation in `real_world_events` table
4. Build predictive model: event type → expected market reaction
5. Use in future trade decisions (avoid/embrace volatility)

**Anomaly Detection**:
- Price moves > 2 standard deviations
- Volume spikes > 3x average
- Correlation breakdowns
- VIX spikes
- Logged in `ai_anomaly_detection` table

---

## Historical Fleet Backtesting

### Fleet Backtesting System (`src/lib/historicalFleetService.ts`)

**Purpose**: Run multiple AI strategies simultaneously on historical data

**Key Functions**:
- `createFleet()`: Initialize multiple AI instances with different configs
- `runBacktest()`: Execute all AIs on same historical data
- `comparePerformance()`: Rank strategies by various metrics
- `exportWinners()`: Promote successful strategies to live paper trading

**Use Cases**:
- Test new strategy ideas before deploying
- Compare variations of existing strategies
- Identify market regime-specific strategies (trending vs ranging)
- Optimize parameters (stop loss %, position sizing, etc.)

**Database**:
- `historical_fleet_runs`: Backtest metadata
- `historical_fleet_accounts`: Individual AI performance in backtest
- `historical_fleet_trades`: All simulated trades from backtest

**Workflow**:
1. User defines date range and symbols
2. System spawns N AI instances (e.g., 10)
3. Each AI uses different strategy/parameters
4. All run on same historical data in parallel
5. Results compared on dashboard
6. Best performer(s) promoted to live paper trading

---

## Strategy System

### Strategy Registry (`src/lib/strategies/registry.ts`)

**Purpose**: Central registry of all available trading strategies

**Built-in Strategies**:
1. **APAM (Adaptive Price Action Model)** - `src/lib/strategies/apam.ts`
   - Manual trading ruleset based on price action
   - Detailed rules in `src/lib/strategies/apam/` directory
   - Uses support/resistance, trend, and volume

2. **Trade Surge** - `src/lib/strategies/tradeSurge.ts`
   - Momentum-based strategy
   - Identifies volume surges with directional bias
   - Quick entries/exits

3. **AI-Evolved Strategies** - Dynamically created
   - Generated by Pattern Discovery system
   - Stored in `ai_evolved_rulesets` table
   - Loaded at runtime if performance validated

### Strategy Interface (`src/lib/strategies/types.ts`)

All strategies must implement:
```typescript
interface TradingStrategy {
  name: string
  version: string
  generateSignal(marketData): TradeSignal | null
  calculatePositionSize(account, signal): number
  managePosition(position, currentPrice): PositionAction
}
```

---

## Follow Mode (Copy Trading)

### Live Signal Broadcasting (`src/lib/followMode.ts`)

**Purpose**: Allow users to follow successful AI traders

**Key Functions**:
- `publishSignal()`: Broadcast trade signal to followers
- `subscribeToSignals()`: Follow a specific AI/user
- `copyTrade()`: Automatically execute follower's trades

**Database Tables**:
- `live_signals`: Published trade signals
- `signal_subscriptions`: Who follows whom
- `signal_performance`: Track record of signal providers

**Signal Flow**:
1. Master AI generates trade signal
2. If AI has followers → publish to `live_signals`
3. Followers receive notification
4. Followers can auto-copy or manually review
5. All trades tracked separately per follower
6. Signal provider's track record updated

**Trust & Safety**:
- Minimum performance threshold to publish signals
- Verified track record (no cherry-picking)
- Follower can set max risk limits
- Automatic unfollow if performance degrades

---

## Database Schema Overview

### User & Accounts
- `users`: (Managed by Supabase Auth)
- `paper_accounts`: Virtual trading accounts with balance
- `user_settings`: User preferences and risk parameters
- `admin_users`: Admin access control

### Trading & Positions
- `simulated_trades`: All paper trades with entry/exit/P&L
- `watchlists`: User-created symbol lists
- `journal_entries`: Trade journal with notes and tags

### AI System Tables
- `ai_evolution_state`: Current AI configuration per account
- `ai_learned_adjustments`: Historical parameter changes
- `ai_drift_rollbacks`: Reverted changes due to poor performance
- `ai_recommendations`: All AI-generated trade ideas
- `ai_training_accounts`: Training AI metadata and performance
- `ai_discovered_patterns`: Patterns found by discovery engine
- `ai_evolved_rulesets`: Codified strategies ready for production
- `account_lineage`: Parent-child relationships between AIs
- `master_ai_spawn_log`: History of spawns/promotions/terminations

### Events & Anomalies
- `real_world_events`: External events affecting markets
- `ai_anomaly_detection`: Unusual market behavior

### Backtesting
- `historical_fleet_runs`: Backtest configurations
- `historical_fleet_accounts`: AI instances in backtest
- `historical_fleet_trades`: Simulated trades from backtest

### Social/Signals
- `live_signals`: Published trade signals for followers
- `signal_subscriptions`: Follow relationships
- `signal_performance`: Track record of signal providers

---

## How AI Should Work (Operational Flow)

### 1. Initial Setup
1. User creates paper trading account ($10,000 starting balance)
2. User selects initial strategy (APAM, Trade Surge, or custom)
3. System creates `ai_evolution_state` with baseline parameters
4. AI begins monitoring watchlist symbols

### 2. Signal Generation Loop
```
Every N minutes (e.g., 5 min during market hours):
  1. Fetch latest price data from Tradier
  2. AI analyzes each watchlist symbol
  3. If signal generated → evaluate against risk rules
  4. If valid → execute paper trade
  5. Record in simulated_trades table
  6. Update ai_recommendations table
```

### 3. Trade Management Loop
```
Every minute during market hours:
  1. Check all open positions
  2. Compare current price vs stop loss and target
  3. If stop hit → close position, record loss
  4. If target hit → close position, record win
  5. Update P&L in paper_accounts
  6. Log outcome in simulated_trades
```

### 4. Evolution Loop
```
Every 24 hours:
  1. Calculate performance metrics (win rate, profit factor, etc.)
  2. Compare vs baseline (stored in ai_evolution_state)
  3. If performance improved → reinforce current parameters
  4. If performance degraded → check for drift
  5. If drift detected → rollback recent changes
  6. Optionally mutate parameters slightly for exploration
  7. Record in ai_learned_adjustments
```

### 5. Pattern Discovery Loop
```
Every 7 days:
  1. Analyze all closed trades from past week
  2. Group winning trades by common features
  3. Run statistical tests for significance
  4. If pattern found → save to ai_discovered_patterns
  5. Backtest pattern on historical data
  6. If validated → add to strategy rotation
```

### 6. Master AI Evaluation Loop
```
Every 30 days:
  1. Evaluate all training accounts
  2. Rank by performance metrics
  3. Top performer(s) → promote to Master AI
  4. Bottom performers → terminate
  5. Master AIs decide whether to spawn new children
  6. Allocate capital based on recent performance
```

---

## AI Decision Making Guidelines

### When to Take a Trade
- Confidence score > 70%
- Odds score > 65%
- Risk/reward ratio > 2:1
- Position size within risk limits (max 2% of account per trade)
- No conflicting signals from other indicators
- Market hours (avoid low liquidity periods)

### When to Avoid a Trade
- Low volume (< 50% of average)
- Wide spread (> 0.5%)
- Major news event imminent
- Max position limit reached
- Recent losses > 3 consecutive
- Drift detected (performance degrading)

### Position Sizing Formula
```
Risk Amount = Account Balance × Risk % (typically 1-2%)
Position Size = Risk Amount / (Entry Price - Stop Loss)
Max Position Size = Account Balance × Max Position % (typically 10%)
Actual Size = min(Calculated Size, Max Position Size)
```

### Stop Loss Placement
- Below recent swing low (long) or above swing high (short)
- Minimum 1% from entry (avoid noise)
- Maximum 5% from entry (cap risk)
- ATR-based: 1.5 × Average True Range

### Target Price Calculation
- Minimum 2× risk distance (if risking $100, target $200 profit)
- Next major support/resistance level
- Fibonacci extension levels
- Previous swing high/low

---

## AI Learning Mechanisms

### 1. Reinforcement Learning (Implicit)
- Winning trades → strengthen similar patterns
- Losing trades → weaken similar patterns
- Parameter adjustments based on reward signal (profit)

### 2. Supervised Learning (Pattern Recognition)
- Historical price patterns → predicted outcomes
- Feature extraction from winning trades
- Build pattern library over time

### 3. Evolutionary Algorithms
- Spawn variations (mutation)
- Select best performers (survival of fittest)
- Cross-breed successful strategies (recombination)

### 4. Meta-Learning
- Learn which strategies work in which market conditions
- Regime detection (trending, ranging, volatile)
- Adaptive strategy selection

---

## Performance Metrics

### Primary Metrics
- **Win Rate**: % of winning trades
- **Profit Factor**: Gross profit / Gross loss
- **Sharpe Ratio**: Risk-adjusted returns
- **Max Drawdown**: Largest peak-to-trough decline
- **Average Win/Loss**: Mean profit vs mean loss

### Secondary Metrics
- Expectancy: (Win% × Avg Win) - (Loss% × Avg Loss)
- Recovery Factor: Net profit / Max drawdown
- Consecutive wins/losses (streak analysis)
- Time in market (exposure)
- Win rate by setup type

### AI-Specific Metrics
- Signal accuracy over time
- Parameter stability (drift score)
- Adaptation speed (time to profitable after spawn)
- Pattern discovery rate (new patterns per month)
- Evolution generations (depth of lineage tree)

---

## User Interface Components

### Key Pages

1. **Dashboard** (`src/pages/Dashboard.tsx`)
   - Account overview, P&L chart, recent trades
   - AI performance summary

2. **Live Signals** (`src/pages/LiveSignals.tsx`)
   - Real-time AI-generated trade signals
   - Follow mode controls

3. **Training Accounts** (`src/pages/TrainingAccounts.tsx`)
   - View all training AI instances
   - Performance comparison
   - Spawn/terminate controls

4. **Master AI** (`src/pages/MasterAI.tsx`)
   - Master AI orchestrator dashboard
   - Spawning decisions
   - Capital allocation

5. **Pattern Discovery** (`src/pages/PatternDiscovery.tsx`)
   - Discovered patterns library
   - Pattern validation results
   - Promotion to production

6. **Historical Fleet** (`src/pages/HistoricalFleet.tsx`)
   - Backtest configuration
   - Fleet performance comparison
   - Export winners to live

7. **Analytics** (`src/pages/Analytics.tsx`)
   - Deep performance metrics
   - Trade analysis
   - Strategy comparison

8. **AI Rulebook** (`src/pages/AIRulebook.tsx`)
   - View/edit AI decision rules
   - Parameter tuning
   - Strategy selection

---

## Implementation Notes for AI

### Data Delay Handling
- All Tradier data is 15 minutes delayed
- For paper trading, this is acceptable (not trying to front-run)
- Real-time data not required for swing/position trading strategies
- For day trading simulations, account for delay in backtest

### Trade Execution Simulation
- Market orders: filled at current price ± 0.05% slippage
- Limit orders: filled if price reaches limit (with queue modeling)
- Stop orders: filled at stop price ± 0.1% slippage
- Partial fills possible on large orders

### Risk Management
- Hard stop: close position if stop loss hit
- Time stop: close position if no movement after N days
- Correlation limit: max exposure to correlated symbols
- Portfolio heat: max % of account at risk simultaneously

### Error Handling
- Tradier API failures → use cached data or skip cycle
- Database errors → log and retry
- Invalid signals → reject and log reason
- Execution failures → alert user, don't continue

---

## Future Enhancement Ideas

1. **Multi-Asset Support**: Extend beyond stocks to options, crypto, forex
2. **Sentiment Analysis**: Integrate news/social media sentiment
3. **Ensemble Models**: Combine multiple AI approaches (neural nets + rule-based)
4. **Automated Hyperparameter Tuning**: Grid search / Bayesian optimization
5. **Market Regime Classification**: Detect and adapt to market conditions
6. **Portfolio Optimization**: Modern portfolio theory integration
7. **Risk Parity**: Balance risk across positions
8. **Factor Investing**: Integrate factor models (value, momentum, quality)
9. **Backtesting Enhancements**: Walk-forward analysis, Monte Carlo simulation
10. **Live Trading**: Eventually connect to real broker for actual execution

---

## Security Considerations

- All trading operations with Tradier are BLOCKED (data feed only)
- RLS policies ensure users only see their own data
- Admin access controlled via `admin_users` table
- API keys stored in Edge Function secrets (not in code)
- No user data exposed in client-side code
- All database mutations go through Supabase RLS

---

## Development Workflow

1. Make changes to AI logic in `src/lib/`
2. Test with paper trading account
3. Monitor performance in Analytics dashboard
4. If successful, promote to production strategy
5. Deploy edge functions via `mcp__supabase__deploy_edge_function` tool
6. Run `npm run build` to verify no TypeScript errors

---

## Key Files Reference

- **AI Engines**: `src/lib/aiEngine.ts`, `src/lib/aiEvolution.ts`, `src/lib/aiDriftEngine.ts`
- **Orchestration**: `src/lib/masterAIOrchestrator.ts`, `src/lib/masterAI.ts`
- **Pattern Discovery**: `src/lib/patternDiscovery.ts`, `src/lib/signalTrackRecord.ts`
- **Trading**: `src/lib/tradierTrading.ts`, `src/lib/tradeSimulator.ts`
- **Data**: `src/lib/tradierApi.ts`, `src/lib/marketData.ts`
- **Strategies**: `src/lib/strategies/` directory
- **Edge Functions**: `supabase/functions/tradier-proxy/index.ts`
- **Database Migrations**: `supabase/migrations/*.sql`

---

## Contact & Support

This platform is designed to be autonomous and self-improving. The AI should continuously learn, adapt, and evolve strategies without manual intervention. Monitor performance metrics and intervene only when drift is significant or system errors occur.

**Remember**: All trading is simulated. No real money is at risk. The goal is to discover profitable strategies in a safe environment before considering live deployment.
